/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.utms_project2;

/**
 *
 * @author pc
 */
public class UTMS_PROJECT2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
